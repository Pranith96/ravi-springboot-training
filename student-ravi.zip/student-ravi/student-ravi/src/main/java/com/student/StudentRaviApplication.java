package com.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRaviApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentRaviApplication.class, args);
	}

}
